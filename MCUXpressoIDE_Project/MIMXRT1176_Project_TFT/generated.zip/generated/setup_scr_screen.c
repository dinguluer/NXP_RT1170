/*
 * Copyright 2022 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl/lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "custom.h"


void setup_scr_screen(lv_ui *ui){

	//Write codes screen
	ui->screen = lv_obj_create(NULL);

	//Write style state: LV_STATE_DEFAULT for style_screen_main_main_default
	static lv_style_t style_screen_main_main_default;
	lv_style_reset(&style_screen_main_main_default);
	lv_style_set_bg_color(&style_screen_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_opa(&style_screen_main_main_default, 0);
	lv_obj_add_style(ui->screen, &style_screen_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write codes screen_img_1
	ui->screen_img_1 = lv_img_create(ui->screen);
	lv_obj_set_pos(ui->screen_img_1, 0, 0);
	lv_obj_set_size(ui->screen_img_1, 500, 388);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_1_main_main_default
	static lv_style_t style_screen_img_1_main_main_default;
	lv_style_reset(&style_screen_img_1_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_1_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_1_main_main_default, 255);
	lv_obj_add_style(ui->screen_img_1, &style_screen_img_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(ui->screen_img_1, LV_OBJ_FLAG_CLICKABLE);
	lv_img_set_src(ui->screen_img_1,&_gauge_500x388);
	lv_img_set_pivot(ui->screen_img_1, 0,0);
	lv_img_set_angle(ui->screen_img_1, 0);

	//Write codes screen_meter_1
	ui->screen_meter_1 = lv_meter_create(ui->screen);
	lv_obj_set_pos(ui->screen_meter_1, 62, 46);
	lv_obj_set_size(ui->screen_meter_1, 388, 388);

	//add scale screen_meter_1_scale_1
	lv_meter_scale_t *screen_meter_1_scale_1 = lv_meter_add_scale(ui->screen_meter_1);
	lv_meter_set_scale_ticks(ui->screen_meter_1, screen_meter_1_scale_1, 60, 0, 0, lv_color_make(0xff, 0x00, 0xea));
	lv_meter_set_scale_range(ui->screen_meter_1, screen_meter_1_scale_1, 0, 60, 270, 135);

	//add needle img for screen_meter_1_scale_1
	ui->screen_meter_1_scale_1_ndimg_0 = lv_meter_add_needle_img(ui->screen_meter_1, screen_meter_1_scale_1, &_gauge_needle_alpha_188x36, 0, 16);
	lv_meter_set_indicator_start_value(ui->screen_meter_1, ui->screen_meter_1_scale_1_ndimg_0, 0);
	lv_meter_set_indicator_end_value(ui->screen_meter_1, ui->screen_meter_1_scale_1_ndimg_0, 60);
	lv_meter_set_indicator_value(ui->screen_meter_1, ui->screen_meter_1_scale_1_ndimg_0, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_meter_1_main_main_default
	static lv_style_t style_screen_meter_1_main_main_default;
	lv_style_reset(&style_screen_meter_1_main_main_default);
	lv_style_set_bg_color(&style_screen_meter_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_meter_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_meter_1_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_meter_1_main_main_default, 0);
	lv_style_set_border_opa(&style_screen_meter_1_main_main_default, 0);
	lv_obj_add_style(ui->screen_meter_1, &style_screen_meter_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for style_screen_meter_1_main_ticks_default
	static lv_style_t style_screen_meter_1_main_ticks_default;
	lv_style_reset(&style_screen_meter_1_main_ticks_default);
	lv_style_set_text_color(&style_screen_meter_1_main_ticks_default, lv_color_make(0xff, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_meter_1_main_ticks_default, &lv_font_simsun_12);
	lv_style_set_bg_opa(&style_screen_meter_1_main_ticks_default, 0);
	lv_obj_add_style(ui->screen_meter_1, &style_screen_meter_1_main_ticks_default, LV_PART_TICKS|LV_STATE_DEFAULT);
}
