#ifndef LV_DISP_GUAGE_APP_H
#define LV_DISP_GUAGE_APP_H

void lv_example_img_Guage(void);

// setup the screen initially
void setup_scr_screen(void);

#endif /*LV_DISP_GUAGE_APP_H*/
