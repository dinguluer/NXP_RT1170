#ifndef LV_DISP_GUAGE_NEEDLE_APP_H
#define LV_DISP_GUAGE_NEEDLE_APP_H

void lv_example_img_Guage_needle(void);

#endif /*LV_DISP_GUAGE_NEEDLE_APP_H*/
