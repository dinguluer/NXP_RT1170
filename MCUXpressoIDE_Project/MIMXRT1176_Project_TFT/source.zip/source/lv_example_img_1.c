#include "lvgl.h"

    LV_IMG_DECLARE(large_size);
    LV_IMG_DECLARE(gear_300_300);

void lv_example_img_1(void)
{

    lv_obj_t * img1 = lv_img_create(lv_scr_act());
    lv_img_set_src(img1, &large_size);
    //lv_obj_align(img1, NULL, LV_ALIGN_CENTER, 0, -20);
    //lv_obj_align(img1, NULL, LV_ALIGN_CENTER, 100, -20);
//    lv_obj_align_x(img1, NULL,LV_ALIGN_IN_TOP_LEFT,20);
//    lv_obj_align_y(img1, NULL,LV_ALIGN_IN_TOP_LEFT,20);
    lv_obj_set_pos(img1,20,20);

    lv_obj_t * img2 = lv_img_create(lv_scr_act());
    //lv_img_set_src(img2, LV_SYMBOL_OK "Accept");
    lv_img_set_src(img2, LV_SYMBOL_WARNING "Accept");
    //lv_obj_align(img2, img1, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
    //lv_obj_align(img2, img1, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
//    lv_obj_align_x(img2, NULL,LV_ALIGN_IN_TOP_LEFT,420);
//    lv_obj_align_y(img2, NULL,LV_ALIGN_IN_TOP_LEFT,220);
    lv_obj_set_pos(img2,420,20);
}


void lv_example_img_2(void)
{

    lv_obj_t * img1 = lv_img_create(lv_scr_act());
    lv_img_set_src(img1, &gear_300_300);
    //lv_obj_align(img1, NULL, LV_ALIGN_CENTER, 0, -20);
    //lv_obj_align(img1, NULL, LV_ALIGN_CENTER, 100, -20);
//    lv_obj_align_x(img1, NULL,LV_ALIGN_IN_TOP_LEFT,20);
//    lv_obj_align_y(img1, NULL,LV_ALIGN_IN_TOP_LEFT,20);
    lv_obj_set_pos(img1,20,20);

    lv_obj_t * img2 = lv_img_create(lv_scr_act());
    //lv_img_set_src(img2, LV_SYMBOL_OK "Accept");
    lv_img_set_src(img2, LV_SYMBOL_WARNING "Accept");
    //lv_obj_align(img2, img1, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
    //lv_obj_align(img2, img1, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
//    lv_obj_align_x(img2, NULL,LV_ALIGN_IN_TOP_LEFT,320);
//    lv_obj_align_y(img2, NULL,LV_ALIGN_IN_TOP_LEFT,320);
    lv_obj_set_pos(img2,320,320);
}
