#ifndef LV_DISP_USER_APP_H
#define LV_DISP_USER_APP_H

void lv_example_img_1(void);
void lv_example_img_2(void);

#endif /*LV_DISP_USER_APP_H*/
