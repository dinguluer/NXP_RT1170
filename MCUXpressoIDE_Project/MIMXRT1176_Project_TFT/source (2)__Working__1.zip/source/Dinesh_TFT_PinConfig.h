///////////////////// Dinesh ///////////////////////
void BOARD_InitTFTPanelPins(void);
void BOARD_InitTFTPanel_Support_Pins(void);
void DEMO_InitLcdBackLight(void);
