#ifndef LV_DISP_GUAGE_NEEDLE_APP_H
#define LV_DISP_GUAGE_NEEDLE_APP_H

void lv_example_img_Guage_needle(void);

extern     lv_obj_t *screen_meter_1;
extern lv_meter_indicator_t *screen_meter_1_scale_1_ndimg_0;

#endif /*LV_DISP_GUAGE_NEEDLE_APP_H*/
