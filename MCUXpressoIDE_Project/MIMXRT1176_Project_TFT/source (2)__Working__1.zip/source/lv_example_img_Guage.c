#include "lvgl.h"

    LV_IMG_DECLARE(guage_image);

    //RK055HDMIPI4M is a 5.5-inch TFT 720x1280 pixels display
    // Image guage : 500*388
    lv_obj_t * img1;

void lv_example_img_Guage(void)
{

    //lv_obj_t * img1 = lv_img_create(lv_scr_act());
    img1 = lv_img_create(lv_scr_act());

    lv_obj_set_pos(img1, 0, 0);
	lv_obj_set_size(img1, 500, 388);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_1_main_main_default
	static lv_style_t style_screen_img_1_main_main_default;
	lv_style_reset(&style_screen_img_1_main_main_default);
	lv_style_set_img_recolor(&style_screen_img_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_img_recolor_opa(&style_screen_img_1_main_main_default, 0);
	lv_style_set_img_opa(&style_screen_img_1_main_main_default, 255);
	lv_obj_add_style(img1, &style_screen_img_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
	lv_obj_add_flag(img1, LV_OBJ_FLAG_CLICKABLE);
	//lv_img_set_src(img1,&_gauge_500x388);
	lv_img_set_src(img1,&guage_image);
	lv_img_set_pivot(img1, 0,0);
	lv_img_set_angle(img1, 0);
}

void setup_scr_screen(void)
{
	//Write style state: LV_STATE_DEFAULT for style_screen_main_main_default
	static lv_style_t style_screen_main_main_default;
	lv_style_reset(&style_screen_main_main_default);
	lv_style_set_bg_color(&style_screen_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_opa(&style_screen_main_main_default, 0);
	lv_obj_add_style(lv_scr_act(), &style_screen_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
}
