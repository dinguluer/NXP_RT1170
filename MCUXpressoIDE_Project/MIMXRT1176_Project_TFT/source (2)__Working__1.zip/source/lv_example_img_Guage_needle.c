#include "lvgl.h"
#include "guider_fonts.h"

    LV_IMG_DECLARE(pointer_needle2);



/* Process to follow :--
    1> draw your gauge image as the background image
    2> create a lvgl guage and set it as transparent (set the opacity)
    3> Set your image as needle image of Guage
 */

    //https://docs.lvgl.io/7.11/widgets/gauge.html
    //RK055HDMIPI4M is a 5.5-inch TFT 720x1280 pixels display
    // Image needle : 188*36
    // guage ; 500*388  --> Guage on display : 110 + 500 + 110

    lv_obj_t *screen_meter_1;
    lv_meter_indicator_t *screen_meter_1_scale_1_ndimg_0;
void lv_example_img_Guage_needle(void)
{

	/*Create a meter*/
	screen_meter_1 = lv_meter_create(lv_scr_act());
	lv_obj_set_pos(screen_meter_1, 62, 46);
	lv_obj_set_size(screen_meter_1, 388, 388);
	//add scale screen_meter_1_scale_1
	lv_meter_scale_t *screen_meter_1_scale_1 = lv_meter_add_scale(screen_meter_1);
	lv_meter_set_scale_ticks(screen_meter_1, screen_meter_1_scale_1, 60, 0, 0, lv_color_make(0xff, 0x00, 0xea));
	lv_meter_set_scale_range(screen_meter_1, screen_meter_1_scale_1, 0, 60, 270, 135);

	//add needle img for screen_meter_1_scale_1
    //screen_meter_1_scale_1_ndimg_0 = lv_meter_add_needle_img(screen_meter_1, screen_meter_1_scale_1, &_gauge_needle_alpha_188x36, 0, 16);
	screen_meter_1_scale_1_ndimg_0 = lv_meter_add_needle_img(screen_meter_1, screen_meter_1_scale_1, &pointer_needle2, 17, 17);
	lv_meter_set_indicator_start_value(screen_meter_1, screen_meter_1_scale_1_ndimg_0, 0);
	lv_meter_set_indicator_end_value(screen_meter_1, screen_meter_1_scale_1_ndimg_0, 60);
	lv_meter_set_indicator_value(screen_meter_1, screen_meter_1_scale_1_ndimg_0, 0);

	//Write style state: LV_STATE_DEFAULT for style_screen_meter_1_main_main_default
	static lv_style_t style_screen_meter_1_main_main_default;
	lv_style_reset(&style_screen_meter_1_main_main_default);
	lv_style_set_bg_color(&style_screen_meter_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_meter_1_main_main_default, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_meter_1_main_main_default, LV_GRAD_DIR_NONE);
	lv_style_set_bg_opa(&style_screen_meter_1_main_main_default, 0);
	lv_style_set_border_opa(&style_screen_meter_1_main_main_default, 0);
	lv_obj_add_style(screen_meter_1, &style_screen_meter_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

	//Write style state: LV_STATE_DEFAULT for style_screen_meter_1_main_ticks_default
	static lv_style_t style_screen_meter_1_main_ticks_default;
	lv_style_reset(&style_screen_meter_1_main_ticks_default);
	lv_style_set_text_color(&style_screen_meter_1_main_ticks_default, lv_color_make(0xff, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_meter_1_main_ticks_default, &lv_font_simsun_12);
	lv_style_set_bg_opa(&style_screen_meter_1_main_ticks_default, 0);
	lv_obj_add_style(screen_meter_1, &style_screen_meter_1_main_ticks_default, LV_PART_TICKS|LV_STATE_DEFAULT);

}
