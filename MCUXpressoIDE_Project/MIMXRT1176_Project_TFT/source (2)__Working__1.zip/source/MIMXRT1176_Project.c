/*
 * Copyright 2020 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

//#include "FreeRTOS.h"
//#include "task.h"

#include "fsl_debug_console.h"
#include "lvgl_support.h"
#include "pin_mux.h"
#include "board.h"
#include "lvgl.h"
//#include "gui_guider.h"
//#include "events_init.h"
//#include "custom.h"

#include "fsl_soc_src.h"

#include "lv_example_img_1.h"
#include "lv_example_img_Guage.h"
#include "lv_example_img_Guage_needle.h"

// dinesh added
#include "fsl_pit.h"

//dinesh added
#include "Dinesh_TFT_PinConfig.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
static volatile bool s_lvgl_initialized = false;
//lv_ui guider_ui;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

#if LV_USE_LOG
static void print_cb(lv_log_level_t level, const char *file, uint32_t line, const char *func, const char *buf)
{
    /*Use only the file name not the path*/
    size_t p;

    for (p = strlen(file); p > 0; p--)
    {
        if (file[p] == '/' || file[p] == '\\')
        {
            p++; /*Skip the slash*/
            break;
        }
    }

    static const char *lvl_prefix[] = {"Trace", "Info", "Warn", "Error", "User"};

    PRINTF("\r%s: %s \t(%s #%d %s())\n", lvl_prefix[level], buf, &file[p], line, func);
}
#endif

static void AppTask(void )
{
#if LV_USE_LOG
    lv_log_register_print_cb(print_cb);
#endif

    int cnt = 0, indic = 0;

    lv_port_pre_init();
    lv_init();
    lv_port_disp_init();
//    lv_port_indev_init();

//    s_lvgl_initialized = true;
//
//    setup_ui(&guider_ui);
//    events_init(&guider_ui);
//    custom_init(&guider_ui);
//
//    for (;;)
//    {
//        lv_task_handler();
//        vTaskDelay(5);
//        if(cnt++ == 10)
//        {
//        	lv_meter_set_indicator_value(guider_ui.screen_meter_1, guider_ui.screen_meter_1_scale_1_ndimg_0, indic++);
//        	if(indic == 60)
//        	{
//        		indic = 0;
//        	}
//        	cnt = 0;
//        }
//    }
}



#define DEMO_FB_ALIGN 64
 #define DEMO_FB_SIZE \
(((DEMO_BUFFER_WIDTH * DEMO_BUFFER_HEIGHT * LCD_FB_BYTE_PER_PIXEL) + DEMO_FB_ALIGN - 1) & ~(DEMO_FB_ALIGN - 1))

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* 1 ms per tick. */
#ifndef LVGL_TICK_MS
#define LVGL_TICK_MS 1U
#endif

/* lv_task_handler is called every 5-tick. */
#ifndef LVGL_TASK_PERIOD_TICK
#define LVGL_TASK_PERIOD_TICK 5U
#endif

#define DEMO_PIT_BASEADDR PIT1
#define DEMO_PIT_CHANNEL  kPIT_Chnl_0
#define DEMO_PIT_GUI_CHANNEL  kPIT_Chnl_1
#define PIT_LED_HANDLER   PIT1_IRQHandler
#define PIT_IRQ_ID        PIT1_IRQn
/* Get source clock for PIT driver */
#define PIT_SOURCE_CLOCK CLOCK_GetRootClockFreq(kCLOCK_Root_Bus)
#define LED_INIT()       USER_LED_INIT(LOGIC_LED_OFF)
#define LED_TOGGLE()     USER_LED_TOGGLE()


/*******************************************************************************
 * Variables
 ******************************************************************************/
static volatile uint32_t s_tick        = 0U;
static volatile bool s_lvglTaskPending = false;

unsigned int  cnt1=0;
unsigned char image_1_flag = 0;
unsigned char image_2_flag = 0;
unsigned char update_screen_flag = 0;

volatile bool pitIsrFlag = false;
volatile bool pitIsrFlag_GUI = false;
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void DEMO_SetupTick(void);
#if LV_USE_LOG
static void print_cb(lv_log_level_t level, const char *file, uint32_t line, const char *func, const char *buf);
#endif


/*******************************************************************************
 * Code
 ******************************************************************************/
void PIT_LED_HANDLER(void)
{
	// channel-0 check flag
	if(PIT_GetStatusFlags(DEMO_PIT_BASEADDR, DEMO_PIT_CHANNEL))
	{
		/* Clear interrupt flag.*/
		PIT_ClearStatusFlags(DEMO_PIT_BASEADDR, DEMO_PIT_CHANNEL, kPIT_TimerFlag);
		pitIsrFlag = true;
	}
	// channel-1 check flag
	if(PIT_GetStatusFlags(DEMO_PIT_BASEADDR, DEMO_PIT_GUI_CHANNEL))
	{
		/* Clear interrupt flag.*/
		PIT_ClearStatusFlags(DEMO_PIT_BASEADDR, DEMO_PIT_GUI_CHANNEL, kPIT_TimerFlag);
		pitIsrFlag_GUI = true;
	}
    /* Added for, and affects, all PIT handlers. For CPU clock which is much larger than the IP bus clock,
     * CPU can run out of the interrupt handler before the interrupt flag being cleared, resulting in the
     * CPU's entering the handler again and again. Adding DSB can prevent the issue from happening.
     */
    __DSB();
}


/* Structure of initialize PIT */
pit_config_t pitConfig;
int cnt = 0, indic = 0 , dir_rotate = 0;

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */
int main(void)
{
    //BaseType_t stat;

    /* Init board hardware. */
    BOARD_ConfigMPU();
    BOARD_BootClockRUN();

    /*
     * Reset the displaymix, otherwise during debugging, the
     * debugger may not reset the display, then the behavior
     * is not right.
     */
    SRC_AssertSliceSoftwareReset(SRC, kSRC_DisplaySlice);

    //    BOARD_InitLpuartPins();
    //    BOARD_InitMipiPanelPins();
    //    BOARD_MIPIPanelTouch_I2C_Init();

        BOARD_InitBootPins();
        //BOARD_InitMipiPanelPins();
        BOARD_InitTFTPanelPins();
        BOARD_InitDebugConsole();

    //AppTask();
//    stat = xTaskCreate(AppTask, "lvgl", configMINIMAL_STACK_SIZE + 800, NULL, tskIDLE_PRIORITY + 2, NULL);
//
//    if (pdPASS != stat)
//    {
//        PRINTF("Failed to create lvgl task");
//        while (1)
//            ;
//    }
//
//    vTaskStartScheduler();

    DEMO_SetupTick();

#if LV_USE_LOG
    lv_log_register_print_cb(print_cb);
#endif

    lv_port_pre_init();
    lv_init();
    lv_port_disp_init();
 //   lv_port_indev_init();

    // Set : LCD_LR, LCD_UD, LCD_RESET, LCD_STDBY
    //BOARD_InitTFTPanel_Support_Pins();

    /* Initialize and enable LED */
    //LED_INIT();  //---> Dinesh

    /********** PIT Module **********************/
    /* pitConfig.enableRunInDebug = false;  */
    PIT_GetDefaultConfig(&pitConfig);
    /* Init pit module */
    PIT_Init(DEMO_PIT_BASEADDR, &pitConfig);
    /* Set timer period for channel 0 */
    PIT_SetTimerPeriod(DEMO_PIT_BASEADDR, DEMO_PIT_CHANNEL, USEC_TO_COUNT(1000000U, PIT_SOURCE_CLOCK)); // 1 sec timer
    /* Enable timer interrupts for channel 0 */
    PIT_EnableInterrupts(DEMO_PIT_BASEADDR, DEMO_PIT_CHANNEL, kPIT_TimerInterruptEnable);
    /* Set timer period for channel 1 */
    PIT_SetTimerPeriod(DEMO_PIT_BASEADDR, DEMO_PIT_GUI_CHANNEL, MSEC_TO_COUNT(250U, PIT_SOURCE_CLOCK));
    /* Enable timer interrupts for channel 1 */
    PIT_EnableInterrupts(DEMO_PIT_BASEADDR, DEMO_PIT_GUI_CHANNEL, kPIT_TimerInterruptEnable);
    /* Enable at the NVIC */
    EnableIRQ(PIT_IRQ_ID);
    /* Start channel 0 */
    PRINTF("\r\nStarting channel No.0 ...");
    PIT_StartTimer(DEMO_PIT_BASEADDR, DEMO_PIT_CHANNEL);
    /* Start channel 1 */
    PRINTF("\r\nStarting channel No.1 ...");
    PIT_StartTimer(DEMO_PIT_BASEADDR, DEMO_PIT_GUI_CHANNEL);

    // setup screen
    setup_scr_screen();
	lv_obj_clean(lv_scr_act());
	lv_example_img_Guage();
	lv_example_img_Guage_needle();
	lv_task_handler();

	__asm volatile ("nop");

    for (;;)
    {
    	if(pitIsrFlag_GUI)
    	{
//        	lv_meter_set_indicator_value(screen_meter_1, screen_meter_1_scale_1_ndimg_0, indic++);
//        	if(indic == 60)
//        	{
//        		indic = 0;
//        	}

        	if(dir_rotate == 0)  // clock wise
        	{
        		indic++;
        		if(indic == 60)
        		{
        			indic = 60;
        			dir_rotate = 1;
        		}
        	}
        	else  // counter-clock wise
        	{
        		indic--;
        		if(indic == 0)
        		{
        			indic = 0;
        			dir_rotate =0;
        		}
        	}
        	lv_meter_set_indicator_value(screen_meter_1, screen_meter_1_scale_1_ndimg_0, indic);

        	pitIsrFlag_GUI = false;
    		lv_task_handler();  // --> Display the content
    	}

//        while (!s_lvglTaskPending)
//        {
//        }
//        s_lvglTaskPending = false;
//
//    	lv_task_handler();
    } /* should never get here */
}

/*!
 * @brief Malloc failed hook.
 */
void vApplicationMallocFailedHook(void)
{
    for (;;)
        ;
}

/*!
 * @brief FreeRTOS tick hook.
 */
void vApplicationTickHook(void)
{
    if (s_lvgl_initialized)
    {
        lv_tick_inc(1);
    }
}

/*!
 * @brief Stack overflow hook.
 */
//void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
//{
//    (void)pcTaskName;
//    (void)xTask;
//
//    for (;;)
//        ;
//}


static void DEMO_SetupTick(void)
{
    if (0 != SysTick_Config(SystemCoreClock / (LVGL_TICK_MS * 1000U)))
    {
        PRINTF("Tick initialization failed\r\n");
        while (1)
            ;
    }
}

void SysTick_Handler(void)
{
    s_tick++;
    lv_tick_inc(LVGL_TICK_MS);

    if ((s_tick % LVGL_TASK_PERIOD_TICK) == 0U)
    {
        s_lvglTaskPending = true;
    }
}
